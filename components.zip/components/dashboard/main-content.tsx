"use client"

import { useDashboard } from "@/lib/dashboard-context"
import { Stage0Home } from "./stages/stage-0-home"
import { Stage1MouthCut } from "./stages/stage-1-mouth-cut"
import { Stage2Preprocessing } from "./stages/stage-2-preprocessing"


export function MainContent() {
  const { currentStage } = useDashboard()

  switch (currentStage) {
    case 0:
      return <Stage0Home />
    case 1:
      return <Stage1MouthCut />
    case 2:
      return <Stage2Preprocessing />
    case 3:
      return (
        <div className="flex h-full items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-foreground">
              Image Classification
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              This stage is under development
            </p>
          </div>
        </div>
      )
    case 4:
      return (
        <div className="flex h-full items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-foreground">
              Video Classification
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              This stage is under development
            </p>
          </div>
        </div>
      )
    case 5:
      return (
        <div className="flex h-full items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-foreground">
              Comparison & Final Results
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              This stage is under development
            </p>
          </div>
        </div>
      )
    default:
      return <Stage0Home />
  }
}